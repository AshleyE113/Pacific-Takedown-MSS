﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playercontroller : MonoBehaviour{
public KeyCode MoveFoward;
public KeyCode MoveBackward;
public KeyCode MoveLeft;
public KeyCode MoveRight;
public float speed;

public int maxHealth = 6;
public int currentHealth;
public HealthBar healthBar;


    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
        healthBar.SetMaxHealth(maxHealth);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(MoveFoward))
            transform.Translate(Vector3.up * speed * Time.deltaTime);
        if (Input.GetKey(MoveBackward))
            transform.Translate(Vector3.down * speed * Time.deltaTime);
        if (Input.GetKey(MoveLeft))
            transform.Translate(Vector3.left * speed * Time.deltaTime);
        if (Input.GetKey(MoveRight))
            transform.Translate(Vector3.right * speed * Time.deltaTime);
        if (Input.GetKeyDown(KeyCode.Space))
        {
            TakeDamage(1);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.tag == "enemy")
        {
            TakeDamage(1);
        }
    }

    void TakeDamage(int damage)
    {
        currentHealth -= damage;

        healthBar.SetHealth(currentHealth);
    }
}
