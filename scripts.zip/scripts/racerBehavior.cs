﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class racerBehavior : MonoBehaviour
{
    public Rigidbody2D myBody;

    public float power;

    public GameObject respawn;

    // Start is called before the first frame update
    void Start()
    {
        myBody = gameObject.GetComponent<Rigidbody2D>();   
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)){
            myBody.AddForce((Vector3.up) * power);
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            myBody.AddForce((Vector3.right) * power);
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            myBody.AddForce((Vector3.left) * power);
        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            myBody.AddForce((Vector3.down) * power);
        }
    }
    void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.tag == "enemy")
        {
            this.transform.position = respawn.transform.position;
        }
    }
}
